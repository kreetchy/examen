/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author pablonoguera
 */
public class Ejercicio4 {
       public static void probarVehiculos() {
            System.out.println("");
          System.out.println("Ejercicio 4");
          System.out.println("");
           System.out.println("Define una clase abstracta llamada Vehiculo con métodos abstractos acelerar() y frenar().\nLuego, crea las clases Coche y Bicicleta que extiendan Vehiculo y proporcionen una implementación para los métodos abstractos.\n");
        // Implementa la lógica del ejercicio 4 aquí 


    }


}

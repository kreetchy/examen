/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;


public class Bicicleta extends Vehiculo {
    public void acelerar() {
        System.out.println("La bicicleta va a acelerar");
         
    }

    public void frenar() {
        System.out.println("La bicicleta va a frenar");
        
    }
}
    /**/


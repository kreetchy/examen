/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author junio
 */
public abstract class Vehiculo {
    
       
        Coche.acelerar();
        Coche.frenar();
        
        Bicicleta.acelerar();
        Bicicleta.frenar();
    }

     


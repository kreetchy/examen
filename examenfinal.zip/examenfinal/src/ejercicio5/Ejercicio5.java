/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio5;

/**
 *
 * @author pablonoguera
 */
public class Ejercicio5 {
        public static void probarConexionRed() {
          System.out.println("");
          System.out.println("Ejercicio 5");
          System.out.println("");
          System.out.println("Crea una interfaz llamada ConexionRed con métodos conectar() y desconectar().\nLuego, implementa esta interfaz en las clases Router y Computadora.\nLa clase Router debe tener un método adicional configurarRed().\n");
        // Implementa la lógica del ejercicio 5 aquí
    }
}

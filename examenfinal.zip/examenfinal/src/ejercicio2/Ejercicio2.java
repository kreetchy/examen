/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;

/**
 *
 * @author pablonoguera
 */
public class Ejercicio2 {
       public static void gestionarClientes() {
            System.out.println("");
          System.out.println("Ejercicio 2");
          System.out.println("");
           System.out.println("Crea una clase llamada RegistroClientes que permita "
                   + "gestionar dinámicamente un conjunto de objetos Cliente."
                   + "\nCada Cliente debe tener un nombre, un número de cliente y un saldo.\nImplementa métodos para agregar un cliente, eliminar un cliente y calcular el saldo total de todos los clientes."
                   + "\nDebe calcular la cantidad de bytes total del prcedimiento calcular saldo total.\n");
        // Implementa la lógica del ejercicio 2 aquí
    }

 
}
